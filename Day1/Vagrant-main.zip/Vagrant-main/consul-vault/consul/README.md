Consul
=========

Install HashiCorp Consul 
